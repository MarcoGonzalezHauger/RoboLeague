import SwiftUI
import Foundation  // For Timer and other utilities

@main
struct RoboLeagueApp: App {
	
	@State private var selectedTeam: Bool? = nil
	@State private var isConnected = false  // Manage view switching here
	@State private var connectionCheckTimer: Timer?  // Store the timer to avoid multiple instances
	
	var body: some Scene {
		WindowGroup {
			if isConnected {
				if let team = selectedTeam {
					RobotController(redTeam: team)
				} else {
					TeamPicker(selectedTeam: $selectedTeam)
				}
			} else {
				SearchingBluetooth(isConnected: $isConnected)
					.onAppear {
						startBluetoothConnectionCheck()	
					}
			}
		}
	}
	
	// Method to periodically check if Bluetooth is connected
	private func startBluetoothConnectionCheck() {
		// Ensure no existing timer is running
		if connectionCheckTimer == nil {
			connectionCheckTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
				if !BluetoothUtility.shared.isBTConnected() {
					isConnected = false  // Update when Bluetooth is disconnected
				}
			}
		}
	}
}
