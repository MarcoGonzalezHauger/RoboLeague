import Foundation
import CoreBluetooth

struct ESP32Device {
	let name: String
	let peripheral: CBPeripheral
}

class BluetoothUtility: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {

	// Singleton instance to use globally across the app
	static let shared = BluetoothUtility()
	
	private var centralManager: CBCentralManager!
	private var discoveredESP32s: [ESP32Device] = []
	private var targetCharacteristic: CBCharacteristic?
	private var connectionCheckTimer: Timer?  // Timer for connection check
	private var isConnected: Bool = false     // Track connection status

	private let serviceUUID = CBUUID(string: "12345678-1234-1234-1234-123456789012")
	private let characteristicUUID = CBUUID(string: "abcdefab-cdef-1234-5678-abcdefabcdef")

	// Callback for when data is received
	var onDataReceived: ((String) -> Void)?

	// Initializer
	private override init() {
		super.init()
		centralManager = CBCentralManager(delegate: self, queue: nil)
	}

	// MARK: - CBCentralManagerDelegate Methods

	func centralManagerDidUpdateState(_ central: CBCentralManager) {
		switch central.state {
		case .poweredOn:
			print("Bluetooth is powered on")
			centralManager.scanForPeripherals(withServices: nil, options: nil)
		case .poweredOff:
			print("Bluetooth is powered off")
			isConnected = false  // If Bluetooth is off, there can't be any connection
		case .resetting:
			print("Bluetooth is resetting")
		case .unauthorized:
			print("Bluetooth is not authorized")
		case .unsupported:
			print("Bluetooth is not supported")
		case .unknown:
			print("Bluetooth state is unknown")
		@unknown default:
			print("A new state is available that is not handled yet")
		}
	}

	// Start scanning for peripherals with the desired service
	func startScanning() {
		print("Scanning for peripherals...")
		centralManager.scanForPeripherals(withServices: nil, options: nil)
	}

	// Stop scanning
	func stopScanning() {
		centralManager.stopScan()
		print("Stopped scanning.")
	}

	// Called when a peripheral is discovered
	func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
		print(advertisementData)
		
		if let peripheralName = peripheral.name {
			print("Discovered peripheral: \(peripheralName)")
			
			// Check if the peripheral's name starts with "ESP32" or "RoboLeague"
			if peripheralName.hasPrefix("ESP32") || peripheralName.hasPrefix("RoboLeague") {
				print("Discovered ESP32 peripheral: \(peripheralName)")
				
				// Add the ESP32 peripheral to the array only if it's not already there
				if !discoveredESP32s.contains(where: { $0.peripheral == peripheral }) {
					let espDevice = ESP32Device(name: peripheralName, peripheral: peripheral)
					discoveredESP32s.append(espDevice)
					// Sort the discovered ESP32s alphabetically by name
					discoveredESP32s.sort(by: { $0.name < $1.name })
				}
			} else {
				print("Discovered non-ESP32 peripheral: \(peripheral.name ?? "Unknown")")
			}
		}
	}

	// Called when a peripheral is disconnected or lost
	func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
		print("Disconnected from peripheral: \(peripheral.name ?? "Unknown")")
		
		// Remove the peripheral from the discovered ESP32 devices list
		discoveredESP32s.removeAll { $0.peripheral == peripheral }
		print("Removed \(peripheral.name ?? "Unknown") from ESP32 list.")
		
		// If no ESP32 devices are connected, set isConnected to false
		if discoveredESP32s.isEmpty {
			isConnected = false
		}
	}

	// Function to return discovered ESP32 devices
	func getAvailableESPs() -> [ESP32Device] {
		return discoveredESP32s
	}

	// Function to connect to a specific ESP32 device
	func connectToESP(_ espDevice: ESP32Device) {
		espDevice.peripheral.delegate = self
		centralManager.connect(espDevice.peripheral, options: nil)
	}

	// Called when a connection is successful
	func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
		print("Connected to \(peripheral.name ?? "Unknown")")
		isConnected = true  // Set the connection flag to true
		peripheral.discoverServices([serviceUUID])
		writeData("Hello, World.")
	}

	// Called when a connection fails
	func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
		print("Failed to connect to peripheral: \(error?.localizedDescription ?? "Unknown error")")
		isConnected = false
	}

	// MARK: - CBPeripheralDelegate Methods

	// Called when services are discovered
	func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
		if let error = error {
			print("Error discovering services: \(error.localizedDescription)")
			return
		}
		
		guard let services = peripheral.services else { return }
		
		for service in services {
			print("Discovered service: \(service.uuid)")
			peripheral.discoverCharacteristics([characteristicUUID], for: service)
		}
	}

	// Called when characteristics are discovered
	func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
		if let error = error {
			print("Error discovering characteristics: \(error.localizedDescription)")
			return
		}
		
		guard let characteristics = service.characteristics else { return }
		
		for characteristic in characteristics {
			if characteristic.uuid == characteristicUUID {
				print("Discovered characteristic: \(characteristic.uuid)")
				targetCharacteristic = characteristic
				peripheral.readValue(for: characteristic)
			}
		}
	}

	// Called when the peripheral updates a characteristic's value
	func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
		if let error = error {
			print("Error updating characteristic value: \(error.localizedDescription)")
			return
		}
		
		if let data = characteristic.value, let receivedString = String(data: data, encoding: .utf8) {
			print("Received data: \(receivedString)")
			onDataReceived?(receivedString)
		}
	}

	var lastData: String = ""  // Holds the last data to be sent
	private var dataSendTimer: DispatchSourceTimer?  // Timer for sending data every 30 seconds
	private var isTimerActive: Bool = false  // Variable to check if the timer is already active

	// MARK: - Write Data to Peripheral
	
	private func startTimerIfNeeded() {
		guard !isTimerActive else { return }
		isTimerActive = true
		
		dataSendTimer = DispatchSource.makeTimerSource(queue: DispatchQueue.global())
		dataSendTimer?.schedule(deadline: .now(), repeating: 1/30)
		dataSendTimer?.setEventHandler { [weak self] in
			self?.sendLastData()
		}
		dataSendTimer?.resume()
	}

	private func sendLastData() {
		guard !lastData.isEmpty else {
			print("No data to send")
			return
		}
		
		guard let peripheral = discoveredESP32s.first?.peripheral, let characteristic = targetCharacteristic else {
			print("Peripheral or characteristic not found")
			return
		}

		let dataToSend = lastData.data(using: .utf8)!
		peripheral.writeValue(dataToSend, for: characteristic, type: .withResponse)
		print("Sent data: \(lastData)")
		lastData = ""
	}

	func writeData(_ data: String) {
		lastData = data
		print("Updated last data: \(data)")
		startTimerIfNeeded()
	}

	// MARK: - Bluetooth Connection Check

	// Method to check if any ESP32 device is connected
	func isBTConnected() -> Bool {
		return isConnected
	}

	// Method to start the Bluetooth connection check
	func startBluetoothConnectionCheck() {
		// Ensure no existing timer is running
		if connectionCheckTimer == nil {
			connectionCheckTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
				if !(self?.isBTConnected() ?? false) {  // Use isBTConnected instead of isConnected()
					print("Bluetooth disconnected")
					// Handle disconnection logic here if needed
				}
			}
		}
	}


	// Method to stop the Bluetooth connection check
	func stopBluetoothConnectionCheck() {
		connectionCheckTimer?.invalidate()
		connectionCheckTimer = nil
	}
}
