import SwiftUI

struct SearchingBluetooth: View {
	@State private var animate = false
	@Binding var isConnected: Bool  // Binding to control view switching from RoboLeagueApp
	@State private var connectionStatus = "Searching for bots..."
	@State private var availableESPs: [ESP32Device] = []  // List of available ESP32 devices
	@State private var pressedESP: UUID?  // Track which ESP is being pressed
	@State private var connectionTimer: Timer?  // Timer for connection timeout
	
	var body: some View {
		ZStack {
			LinearGradient(colors: [Color(red: 20/255, green: 20/255, blue: 20/255), Color(red: 27/255, green: 32/255, blue: 72/255)], startPoint: .top, endPoint: .bottom)
			
			ZStack {
				ForEach(0..<5, id: \.self) { i in
					CircleWave()
						.opacity(Double(5 - i) / 3)
						.scaleEffect(animate ? 20 : 0.01)
						.animation(
							.easeOut(duration: 13)
							.repeatForever(autoreverses: false)
							.delay(Double(i) * (13/5)), value: animate
						)
						.offset(y: -16)
				}
			}
			.onAppear {
				animate = true
				startBluetoothScan()
			}
			
			VStack(spacing: 22) {
				Image("np_bluetooth_1881548_FFFFFF 1")
					.resizable()
					.frame(width: 41, height: 41)
				Text(connectionStatus)
					.font(.system(size: 12))
					.foregroundColor(.white)
				
				// Only show the list of available ESP32 devices if still searching
				if connectionStatus == "Searching for bots..." {
					HStack(spacing: 10) {
						ForEach(availableESPs, id: \.peripheral.identifier) { esp in
							Button {
								connectToESP(esp)
							} label: {
								ZStack {
									VStack(spacing: 4) {
										Image("Bot Icon")
											.resizable()
											.frame(width: 31, height: 31)
										Text(esp.name.replacingOccurrences(of: "RoboLeague-", with: ""))
											.font(.system(size: 12))
											.foregroundColor(.white)
									}
									Image("Bot Orb")
										.resizable()
										.frame(width: 95, height: 95)
								}
							}
							.scaleEffect(pressedESP == esp.peripheral.identifier ? 0.9 : 1.0)  // Scale only the pressed ESP
							.animation(.spring(response: 0.3, dampingFraction: 0.6, blendDuration: 0), value: pressedESP)  // Spring animation for smooth scaling
							.gesture(
								DragGesture(minimumDistance: 0)
									.onChanged { _ in
										pressedESP = esp.peripheral.identifier  // Set pressedESP to the current ESP's identifier
									}
									.onEnded { _ in
										pressedESP = nil  // Reset when the gesture ends
									}
							)
						}
					}
				}
			}
			
			VStack {
				Spacer()
				HStack(alignment: .bottom) {
					Image("VT HAX Logo 1").resizable().frame(width: 141, height: 38).padding(.leading, 14).padding(.bottom, 18)
					Spacer()
					Image("Logo 1").resizable().frame(width: 201, height: 94).padding(.trailing, 27).padding(.bottom, 18)
				}
			}
		}.ignoresSafeArea()
	}
	
	// Method to start scanning for ESP32 devices and updating available devices
	private func startBluetoothScan() {
		// Set the callback to update UI when data is received from ESP32
		BluetoothUtility.shared.onDataReceived = { data in
			connectionStatus = "Connected to bot!"
			
			// Invalidate the connection timer when connected
			connectionTimer?.invalidate()
			
			// Wait for 1.5 seconds before switching to the RobotController view
			DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) {
				isConnected = true  // Trigger view switch after delay
			}
		}
		
		// Start scanning for ESP32 devices
		BluetoothUtility.shared.startScanning()
		
		// Timer to check for new ESP32 devices every second
		Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
			availableESPs = BluetoothUtility.shared.getAvailableESPs()
		}
	}
	
	// Method to connect to the selected ESP32 device
	private func connectToESP(_ esp: ESP32Device) {
		BluetoothUtility.shared.connectToESP(esp)
		connectionStatus = "Connecting to \(esp.name)..."
		
		// Clear the list of available ESPs to make other options disappear
		availableESPs.removeAll()
		
		// Invalidate any existing timer before starting a new one
		connectionTimer?.invalidate()
		
		// Set a timeout for 8 seconds to return to BT selection mode if no connection is made
		connectionTimer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: false) { _ in
			if connectionStatus != "Connected to bot!" {
				connectionStatus = "Searching for bots..."
				startBluetoothScan()  // Restart the Bluetooth scan
			}
		}
	}
}

struct CircleWave: View {
	var body: some View {
		Image("Ellipse 2")
			.resizable()
			.frame(width: 100, height: 100)
	}
}

#Preview {
	SearchingBluetooth(isConnected: .constant(false))
}
