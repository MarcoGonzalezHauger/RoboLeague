//
//  RobotController.swift
//  RoboLeague
//
//  Created by Marco Gonzalez Hauger on 9/14/24.
//

import SwiftUI

func mediumImpact() {
	let generator = UIImpactFeedbackGenerator(style: .rigid) // You can use .light, .medium, or .heavy
	generator.impactOccurred()
}


func heavyImpact() {
	let generator = UIImpactFeedbackGenerator(style: .heavy) // You can use .light, .medium, or .heavy
	generator.impactOccurred()
}

import SwiftUI

struct KickButton: View {
	@Binding var isPressed: Bool  // Use a binding so the pressed state is shared with the parent view
	var onKick: () -> Void  // Closure that will be triggered when the button is pressed
	
//	@State private var isCoolingDown = false  // To track if the button is cooling down
//	@State private var rechargeProgress: CGFloat = 1.0  // To track the recharge progress
	
//	let rechargeTime: TimeInterval = 3.0  // Cooldown time in seconds
	
	var body: some View {
		ZStack {
			// Recharge background circle
//			Circle()
//				.fill(rechargeProgress == 1 ? Color.white.opacity(0.2) : Color.white.opacity(0.5))
//				.frame(width: 170, height: 170)
//				.mask(
//					Circle()
//						.scale(rechargeProgress)
//				)
//				.scaleEffect(isPressed ? 0.9 : 1.0)  // Compress when pressed
//				.animation(.spring(response: 0.3, dampingFraction: 0.3), value: isPressed)  // Add spring animation
//			
			// Main kick aura image
			Image("Kick Aura")
				.resizable()
				.frame(width: 170, height: 170)
				.scaleEffect(isPressed ? 0.9 : 1.0)  // Compress when pressed
				.animation(.spring(response: 0.3, dampingFraction: 0.3), value: isPressed)  // Add spring animation
			
			// Kick image
			Image("Kick")
				.resizable()
				.frame(width: 85, height: 71)
				.scaleEffect(isPressed ? 1.5 : 1.0)  // Compress when pressed
				.animation(.spring(response: 0.3, dampingFraction: 0.3), value: isPressed)  // Add spring animation
		}
		.simultaneousGesture(DragGesture(minimumDistance: 0)
			.onChanged { _ in
				BluetoothUtility.shared.writeData("K")
				heavyImpact()
				//				if !isCoolingDown {
				mediumImpact()
				onKick()  // Call the closure to send the kick command
				isPressed = true  // Button is pressed
				//					startRecharge()  // Start the cooldown timer
				//				}
			}
			.onEnded { _ in
				BluetoothUtility.shared.writeData("O")
				isPressed = false  // Button is released
			}
		)
	}
	
	// Start the recharge process (cooldown)
	//	private func startRecharge() {
//		isCoolingDown = true  // Prevent further kicks
//		rechargeProgress = 0.0  // Start the progress from 0 (empty)
//
//		// Animate recharge over 3 seconds
//		withAnimation(.linear(duration: rechargeTime)) {
//			rechargeProgress = 1.0  // Fill up the progress to full over rechargeTime
//		}
//
//		// After the recharge time, reset the cooldown
//		DispatchQueue.main.asyncAfter(deadline: .now() + rechargeTime) {
//			isCoolingDown = false  // Enable kick again after cooldown
//		}
//	}
}


struct Joystick: View {
	
	// Function to compute the angle from the center based on the offset
	func computeZoneFromOffset(offset: CGSize) -> String {
		if offset == .zero {
			return "N"
		}
		if sqrt(pow(offset.height, 2) + pow(offset.width, 2)) < 10 {
			return lastZone
		}
		let angleInDegrees = atan2(offset.height, offset.width) * 180 / .pi
		return mapDegreesToZone(degrees: angleInDegrees)
	}
	
	func mapDegreesToZone(degrees: CGFloat) -> String {
		
		let adjustedDegrees = degrees < 0 ? degrees + 360 : degrees // Normalize to 0-360
		
		// Define zones with B at the top (90º for forward), then rotating clockwise.
		switch adjustedDegrees {
		case 67.5..<112.5: return "B"
		case 112.5..<157.5: return "W"
		case 157.5..<202.5: return "L"
		case 202.5..<247.5: return "X"
		case 247.5..<292.5: return "F"
		case 292.5..<337.5: return "Y"
		case 337.5..<360, 0..<22.5: return "R"
		case 22.5..<67.5: return "Z"
		default: return "N"
		}
	}
	
	let nubRadius: CGFloat = 60.0
	let areaRadius: CGFloat = 122.0
	let interactionAreaSize: CGFloat = 300.0
	
	@State var lastZone: String = "N"
	@State var zone: String = "N"
	
	@State private var nubOffset: CGSize = .zero
	@State private var startOffset: CGSize = .zero // Track the starting offset
	
	var body: some View {
		ZStack {
			Text(zone)
				.font(.system(size: 50))
				.bold()
				.foregroundColor(.white)
				.offset(x: 250)
			// Movable Nub
			Image("Joystick")
				.resizable()
				.frame(width: areaRadius * 2, height: areaRadius * 2)
				.overlay(
					// The movable nub
					Image("Nub")
						.resizable()
						.frame(width: nubRadius * 2, height: nubRadius * 2)
						.offset(nubOffset) // Apply the offset for movement
				)
				.overlay(
					// Detect taps and drags in a 300x300 area around the nub
					Color.clear
						.frame(width: interactionAreaSize, height: interactionAreaSize)
						.contentShape(Rectangle()) // Make the area tappable
						.gesture(
							DragGesture(minimumDistance: 0)
								.onChanged { gesture in
									// Calculate the relative movement from where the drag started
									let xOffset = startOffset.width + gesture.translation.width
									let yOffset = startOffset.height + gesture.translation.height
									
									// Update the nub's offset
									nubOffset = CGSize(width: xOffset, height: yOffset)
									zone = computeZoneFromOffset(offset: nubOffset)
									if lastZone != zone {
										if zone == "F" {
											heavyImpact()
										} else {
											mediumImpact()
										}
										BluetoothUtility.shared.writeData(zone)
									}
									lastZone = zone
									
								}
								.onEnded { _ in
									// Reset the nub position to the starting offset when released
									nubOffset = startOffset
									zone = computeZoneFromOffset(offset: nubOffset)
									if lastZone != zone {
										mediumImpact()
										BluetoothUtility.shared.writeData(zone)
									}
									lastZone = zone
								}
						)
				)
		}
	}
}


struct RobotController: View {
	
	@State var redTeam: Bool = true
	@State var myScore: Int = 0
	@State var oppScore: Int = 0
	@State private var isPressed = false
	
	let winningNumber = 3
	
	let redColor: Color = Color(red: 74/255, green: 0, blue: 0)
	let blueColor: Color = Color(red: 0, green: 8/255, blue: 80/255)
	
	func computeOffsetFromScore(score1: Int, score2: Int) -> CGFloat {
		
		var differential = CGFloat(score1) - CGFloat(score2)
		
		if score1 >= winningNumber && score2 >= winningNumber {
			return CGFloat(200.0/3) * differential
		}
		
		if score1 >= winningNumber {
			return CGFloat(700.0)
		}
		if score2 >= winningNumber {
			return CGFloat(-700.0)
		}
		
		return CGFloat(200.0/3) * differential
	}
	
	func getGameTextForScore(score1: Int, score2: Int) -> String {
		
		if score1 >= winningNumber && score2 >= winningNumber {
			return "FREEPLAY"
		}
		
		if score1 >= winningNumber {
			return "YOU WIN!"
		}
		if score2 >= winningNumber {
			return "YOU LOST!"
		}
		
		return "FIRST TO 3"
	}
	
	var body: some View {
		ZStack {
			
			LinearGradient(
				gradient: Gradient(stops: [
					.init(color: blueColor, location: 0.45),
					.init(color: Color(red: 0, green: 0, blue: 0), location: 0.5),
					.init(color: redColor, location: 0.55)
				]),
				startPoint: .leading,
				endPoint: .trailing
			)
			.scaleEffect(5)
			.edgesIgnoringSafeArea(.all) // Extend gradient to full screen
			.rotationEffect(!redTeam ? Angle.degrees(0) : Angle.degrees(180)) // Rotate the entire ZStack
			.animation(.easeInOut(duration: 0.5), value: redTeam)
			.offset(x: computeOffsetFromScore(score1: myScore, score2: oppScore))
			.animation(.easeInOut(duration: 0.5), value: myScore)
			.animation(.easeInOut(duration: 0.5), value: oppScore)
			
			VStack {
				Spacer()
				HStack(alignment: .bottom) {
					Image("VT HAX Logo 1").resizable().frame(width: 141, height: 38) .padding(.leading, 14).padding(.bottom, 18)
					Spacer()
					Image("Logo 1").resizable().frame(width: 130, height: 61) .padding(.trailing, 27).padding(.bottom, 18)
				}
			}.opacity(0.65)
			
			VStack {
				Spacer()
				HStack(spacing: 41) {
					// Upper Button Section for Score Adjustment
					HStack(spacing: 3) {
						
						Button {
							myScore = max(0, myScore - 1)
							mediumImpact()
						} label: {
							Image(redTeam ? "Red Minus" : "Blue Minus")
								.resizable()
								.frame(width: 70, height: 70)
						}
						
						
						Button {
							myScore += 1
							mediumImpact()
						} label: {
							Image(redTeam ? "Red Plus" : "Blue Plus")
								.resizable()
								.frame(width: 70, height: 70)
						}
					}
					
					
					// Upper Button Section for Score Adjustment
					HStack(spacing: 3) {
						
						Button {
							oppScore = max(0, oppScore - 1)
							mediumImpact()
						} label: {
							Image(!redTeam ? "Red Minus" : "Blue Minus")
								.resizable()
								.frame(width: 70, height: 70)
						}
						
						
						Button {
							oppScore += 1
							mediumImpact()
						} label: {
							Image(!redTeam ? "Red Plus" : "Blue Plus")
								.resizable()
								.frame(width: 70, height: 70)
						}
					}
					
					// Lower Button Section for Game Controls
					HStack(spacing: 3) {
						
						Button {
							myScore = 0
							oppScore = 0
							mediumImpact()
						} label: {
							Image("Reset Game")
								.resizable()
								.frame(width: 70, height: 70)
						}
						
						Button {
							redTeam = !redTeam
							swap(&myScore, &oppScore)
							mediumImpact()
						} label: {
							Image("Switch Colors")
								.resizable()
								.frame(width: 70, height: 70)
								.rotationEffect(redTeam ? Angle.degrees(0) : Angle.degrees(180))
						}
					}
				}
				.padding(.bottom, 13)
			}
			
			VStack {
				HStack(alignment: .top) {
					ZStack {
						Image(redTeam ? "Red Score" : "Blue Score").resizable().frame(width: 85, height: 85)
						VStack(spacing: 0) {
							Text("YOU")
								.font(.system(size: 12, weight: .thin))
								.italic()
								.foregroundColor(.white)
								.offset(y: 8)
							Text("\(myScore)")
								.font(.system(size: 60, weight: .heavy))
								.italic()
								.foregroundColor(.white)
						}
					}
					Spacer()
					Text(getGameTextForScore(score1: myScore, score2: oppScore))
						.font(.system(size: 28, weight: .heavy))
						.italic()
						.foregroundColor(.white)
					Spacer()
					ZStack {
						Image(!redTeam ? "Red Score" : "Blue Score").resizable().frame(width: 85, height: 85)
						VStack(spacing: 0) {
							Text("OPPONENT")
								.font(.system(size: 12, weight: .thin))
								.italic()
								.foregroundColor(.white)
								.offset(y: 8)
							Text("\(oppScore)")
								.font(.system(size: 60, weight: .heavy))
								.italic()
								.foregroundColor(.white)
						}
					}
				}.padding(.all, 9)
				Spacer()
			}
			VStack {
				HStack {
					Joystick()
						.padding(.leading, 85)
						.padding(.top, 38)
					Spacer()
				}
				Spacer()
			}
			
			VStack {
				HStack {
					Spacer()
//					KickButton(isPressed: $isPressed) {
//					}
//					.padding(.top, 65)
//					.padding(.trailing, 106)
					
				}
				Spacer()
			}
			
		}.ignoresSafeArea()
	}
}

#Preview {
	RobotController()
}
