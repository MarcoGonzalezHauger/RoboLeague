import SwiftUI

// Define OrbView struct for reuse
struct OrbView: View {
	
	let imageName: String
	let optionName: String
	let size: CGFloat
	@State private var scale: CGFloat = 0.0
	let delay: Double // Add a delay parameter for custom timing

	var body: some View {
		ZStack {
			Image(imageName)
				.resizable()
				.frame(width: size, height: size)
				.clipped()
				.scaleEffect(1 + scale) // Apply scale effect

			Image(optionName)
				.resizable()
				.scaledToFit()
				.frame(height: 82)
				.scaleEffect(1 - (scale * 2)) // Apply scale effect to this image as well
		}
		.onAppear {
			// Infinite spring animation with optional delay
			withAnimation(.spring(response: 5, dampingFraction: 0).delay(delay)) {
				scale = 0.05
			}
		}
	}
}

struct TeamPicker: View {
	
	@Binding var selectedTeam: Bool?
	
	var body: some View {
		ZStack {
			LinearGradient(colors: [Color(red: 74/255, green: 0, blue: 0),
									Color(red: 74/255, green: 0, blue: 0),
									Color.black,
									Color(red: 0, green: 8/255, blue: 80/255),
									Color(red: 0, green: 8/255, blue: 80/255)],
						   startPoint: .leading,
						   endPoint: .trailing)
			
			GeometryReader { geometry in
				HStack(spacing: 48) {
					// Use OrbView to show Red Orb (no delay)
					Button {
						selectedTeam = true
					} label: {
						OrbView(imageName: "Red Orb", optionName: "Red Option", size: 442, delay: 0)
					}
					// Use OrbView to show Blue Orb (with 2-second delay)
					Button {
						selectedTeam = false
					} label: {
						OrbView(imageName: "Blue Orb", optionName: "Blue Option", size: 442, delay: 1.5)
					}
				}
				.frame(width: geometry.size.width, height: geometry.size.height)
				.clipped()
			}

			VStack {
				Image("Logo 1")
					.resizable()
					.frame(width: 201, height: 94)
					.padding(.top, 26)
				Spacer()
				ZStack {
					HStack {
						Spacer()
						Text("PICK A TEAM")
							.foregroundColor(.white)
							.font(.system(size: 22))
							.bold().italic()
						Spacer()
					}
					HStack {
					 Image("VT HAX Logo 1")
						 .resizable()
						 .frame(width: 141, height: 38)
						 .padding(.leading, 14)
						 .padding(.bottom, 18)
					 Spacer()
				 }
				}
			}
		}
		.ignoresSafeArea()
	}
}

#Preview {
	TeamPicker(selectedTeam: .constant(nil))
}
